import pygame
import random
import pygame 

pygame.init()

# Класс врага
class Enemy(pygame.sprite.Sprite):  # Наследуемся от pygame.sprite.Sprite
    def __init__(self, image, x, y, width, height):
        super().__init__()  # Инициализируем базовый класс
        self.original_image = pygame.transform.scale(pygame.image.load(image), (width, height)).convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect(topleft=(x, y))
        self.x = x  
        self.y = y
        self.direction = "DOWN"  # Начальное направление

    # Отрисовка и движение врага
    def update(self, screen, target_x, target_y):
        if self.x < target_x:
            self.x += 1
            self.direction = "RIGHT"
        elif self.x > target_x:
            self.x -= 1
            self.direction = "LEFT"

        if self.y < target_y:
            self.y += 1
            self.direction = "DOWN"
        elif self.y > target_y:
            self.y -= 1
            self.direction = "UP"

        # Поворот изображения в зависимости от направления
        if self.direction == "UP":
            self.image = pygame.transform.rotate(self.original_image, 0)
        elif self.direction == "DOWN":
            self.image = pygame.transform.rotate(self.original_image, 180)
        elif self.direction == "LEFT":
            self.image = pygame.transform.rotate(self.original_image, 90)
        elif self.direction == "RIGHT":
            self.image = pygame.transform.rotate(self.original_image, -90)

        self.rect.topleft = (self.x, self.y)
        screen.blit(self.image, (self.x, self.y))

